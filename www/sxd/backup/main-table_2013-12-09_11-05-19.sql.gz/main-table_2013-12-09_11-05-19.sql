#SXD20|20010|50534|50505|2013.12.09 11:05:19|yacht-book|0|50|423|
#TA c_profile`0`16384|c_rating`0`16384|cc_cancel_period`0`16384|cc_early_period`0`16384|cc_fleets`0`16384|cc_long_period`0`16384|cc_order_comfort_packs`0`16384|cc_order_options`0`16384|cc_payments_period`0`16384|cc_profile`0`16384|cc_questionnaire`0`16384|cc_transit_log`0`16384|duration_type`5`16384|engine_mark`4`16384|engine_type`3`16384|friends_link`0`16384|friends_link_type`4`16384|gender`2`16384|jib_furling`2`16384|jib_type`2`16384|m_profile`0`16384|media_type`4`16384|message`0`16384|nationality`2`16384|order_options`0`16384|order_status`5`16384|order_status_history`0`16384|orders`0`16384|price_current_year`0`16384|price_next_year`0`16384|questions`0`16384|rights_auth_assignment`1`16384|rights_auth_item`7`16384|rights_auth_item_child`6`16384|rights_rights`0`16384|sail_furling`0`16384|sail_material`0`16384|sy_profile`0`16384|tbl_profiles`2`16384|tbl_profiles_fields`2`16384|tbl_users`2`16384|wheel_type`0`16384|yacht_favorites`0`16384|yacht_history_watch`0`16384|yacht_index`262`16384|yacht_model`46`16384|yacht_modification`42`16384|yacht_photo`0`16384|yacht_shipyard`18`16384|yacht_type`2`16384
#EOH

#	TC`c_profile`utf8_general_ci	;
CREATE TABLE `c_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) NOT NULL COMMENT 'ID капитана',
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `name_eng` text,
  `name_rus` text,
  `last_name_eng` text,
  `last_name_rus` text,
  `sex_id` int(11) DEFAULT NULL,
  `zagran_passport` text,
  `expire_date` date DEFAULT NULL,
  `nationality_id` int(11) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` text,
  `site_commission` int(11) DEFAULT NULL,
  `avatar` text,
  `license` text,
  `school_issued` text,
  `date_issued` date DEFAULT NULL,
  `scan_of_license` text,
  `website` text,
  `receive_news` tinyint(1) DEFAULT NULL,
  `professional_regatta` tinyint(1) DEFAULT NULL,
  `amateur_regatta` tinyint(1) DEFAULT NULL,
  `repeater` int(11) DEFAULT NULL,
  `extra` int(11) DEFAULT NULL,
  `last_settings` text COMMENT 'Массив сохраненных настроек',
  PRIMARY KEY (`id`),
  KEY `sex_id` (`sex_id`),
  KEY `c_id` (`c_id`),
  KEY `nationality_id` (`nationality_id`),
  CONSTRAINT `c_profile_ibfk_1` FOREIGN KEY (`sex_id`) REFERENCES `gender` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_profile_ibfk_2` FOREIGN KEY (`c_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_profile_ibfk_3` FOREIGN KEY (`nationality_id`) REFERENCES `nationality` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Профиль капитана'	;
#	TC`c_rating`utf8_general_ci	;
CREATE TABLE `c_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cc_id` (`cc_id`),
  KEY `c_id` (`c_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `c_rating_ibfk_1` FOREIGN KEY (`cc_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_rating_ibfk_2` FOREIGN KEY (`c_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_rating_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Рейтинг капитана'	;
#	TC`cc_cancel_period`utf8_general_ci	;
CREATE TABLE `cc_cancel_period` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_profile_id` int(11) NOT NULL,
  `value` float NOT NULL,
  `before_duration` int(11) NOT NULL,
  `duration_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cc_profile_id` (`cc_profile_id`),
  KEY `duration_type_id` (`duration_type_id`),
  CONSTRAINT `cc_cancel_period_ibfk_1` FOREIGN KEY (`cc_profile_id`) REFERENCES `cc_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_cancel_period_ibfk_2` FOREIGN KEY (`duration_type_id`) REFERENCES `duration_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Описание периодов отмены заказа ЧК'	;
#	TC`cc_early_period`utf8_general_ci	;
CREATE TABLE `cc_early_period` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_profile_id` int(11) NOT NULL,
  `value` float NOT NULL,
  `before_duration` int(11) NOT NULL,
  `duration_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cc_profile_id` (`cc_profile_id`),
  KEY `duration_type_id` (`duration_type_id`),
  CONSTRAINT `cc_early_period_ibfk_1` FOREIGN KEY (`cc_profile_id`) REFERENCES `cc_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_early_period_ibfk_2` FOREIGN KEY (`duration_type_id`) REFERENCES `duration_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Описание периодов раннего бронирования ЧК'	;
#	TC`cc_fleets`utf8_general_ci	;
CREATE TABLE `cc_fleets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_id` int(11) NOT NULL COMMENT 'ID чартерной компании',
  `profile_id` int(11) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `isTrash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cc_id` (`cc_id`),
  KEY `profile_id` (`profile_id`),
  CONSTRAINT `cc_fleets_ibfk_1` FOREIGN KEY (`cc_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_fleets_ibfk_2` FOREIGN KEY (`profile_id`) REFERENCES `sy_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица флота чартерных компаний - содержит модификации яхт'	;
#	TC`cc_long_period`utf8_general_ci	;
CREATE TABLE `cc_long_period` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_profile_id` int(11) NOT NULL,
  `value` float NOT NULL,
  `before_duration` int(11) NOT NULL,
  `duration_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cc_profile_id` (`cc_profile_id`),
  KEY `duration_type_id` (`duration_type_id`),
  CONSTRAINT `cc_long_period_ibfk_1` FOREIGN KEY (`cc_profile_id`) REFERENCES `cc_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_long_period_ibfk_2` FOREIGN KEY (`duration_type_id`) REFERENCES `duration_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Описание периодов длительного бронирования ЧК'	;
#	TC`cc_order_comfort_packs`utf8_general_ci	;
CREATE TABLE `cc_order_comfort_packs` (
  `id` int(11) NOT NULL,
  `cc_profile_id` int(11) NOT NULL,
  `options_id` text NOT NULL COMMENT 'Массив ID опций в пакете',
  `description` text NOT NULL,
  `obligatory` tinyint(1) NOT NULL DEFAULT '0',
  `included` tinyint(1) NOT NULL DEFAULT '0',
  `price` float NOT NULL,
  KEY `cc_profile_id` (`cc_profile_id`),
  CONSTRAINT `cc_order_comfort_packs_ibfk_1` FOREIGN KEY (`cc_profile_id`) REFERENCES `cc_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`cc_order_options`utf8_general_ci	;
CREATE TABLE `cc_order_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_profile_id` int(11) NOT NULL,
  `order_option_id` int(11) NOT NULL,
  `obligatory` tinyint(1) NOT NULL DEFAULT '0',
  `included` tinyint(1) NOT NULL DEFAULT '0',
  `price` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cc_profile_id` (`cc_profile_id`),
  KEY `order_option_id` (`order_option_id`),
  CONSTRAINT `cc_order_options_ibfk_1` FOREIGN KEY (`cc_profile_id`) REFERENCES `cc_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_order_options_ibfk_2` FOREIGN KEY (`order_option_id`) REFERENCES `order_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Связь опций заказов с профилем ЧК'	;
#	TC`cc_payments_period`utf8_general_ci	;
CREATE TABLE `cc_payments_period` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_profile_id` int(11) NOT NULL,
  `value` float NOT NULL,
  `before_duration` int(11) NOT NULL,
  `duration_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cc_profile_id` (`cc_profile_id`),
  KEY `duration_type_id` (`duration_type_id`),
  CONSTRAINT `cc_payments_period_ibfk_1` FOREIGN KEY (`cc_profile_id`) REFERENCES `cc_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_payments_period_ibfk_2` FOREIGN KEY (`duration_type_id`) REFERENCES `duration_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Описание платежных периодов ЧК'	;
#	TC`cc_profile`utf8_general_ci	;
CREATE TABLE `cc_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_id` int(11) NOT NULL COMMENT 'ID чартерной компании',
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `company_name` text,
  `company_country_id` int(10) unsigned DEFAULT NULL,
  `company_city_id` int(64) DEFAULT NULL,
  `company_postal_code` varchar(10) DEFAULT NULL,
  `company_full_addres` text,
  `company_web_site` text,
  `company_email` text,
  `company_phone` varchar(15) DEFAULT NULL,
  `company_faxe` varchar(15) DEFAULT NULL,
  `vat` varchar(20) DEFAULT NULL,
  `company_logo` text,
  `q_boat` int(11) DEFAULT NULL,
  `company_speak` text,
  `longitude` int(11) DEFAULT NULL,
  `latitude` int(11) DEFAULT NULL,
  `bank_name` text,
  `bank_addres` text,
  `beneficiary` text,
  `beneficiary_addres` text,
  `account_no` text,
  `swift` text,
  `iban` text,
  `visa` tinyint(1) NOT NULL DEFAULT '0',
  `visa_percent` int(11) DEFAULT NULL,
  `mastercard` tinyint(1) NOT NULL DEFAULT '0',
  `mastercard_percent` int(11) DEFAULT NULL,
  `amex` tinyint(1) NOT NULL DEFAULT '0',
  `amex_percent` int(11) DEFAULT NULL,
  `bank_transfer` tinyint(1) NOT NULL DEFAULT '0',
  `western_union` tinyint(1) NOT NULL DEFAULT '0',
  `contact` tinyint(1) NOT NULL DEFAULT '0',
  `others` text,
  `checkin_day` int(11) DEFAULT NULL,
  `checkin_hour` int(11) DEFAULT NULL,
  `checkout_day` int(11) DEFAULT NULL,
  `checkout_hour` int(11) DEFAULT NULL,
  `payment_other` text,
  `cancel_other` text,
  `repeater_discount` int(11) NOT NULL DEFAULT '0',
  `max_discount` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cc_id` (`cc_id`),
  CONSTRAINT `cc_profile_ibfk_1` FOREIGN KEY (`cc_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Профиль чартерной компании'	;
#	TC`cc_questionnaire`utf8_general_ci	;
CREATE TABLE `cc_questionnaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) NOT NULL,
  `cc_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `c_id` (`c_id`),
  KEY `cc_id` (`cc_id`),
  KEY `order_id` (`order_id`),
  KEY `question_id` (`question_id`),
  CONSTRAINT `cc_questionnaire_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_questionnaire_ibfk_2` FOREIGN KEY (`cc_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_questionnaire_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cc_questionnaire_ibfk_4` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Рейтинг ЧК'	;
#	TC`cc_transit_log`utf8_general_ci	;
CREATE TABLE `cc_transit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_profile_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `obligatory` tinyint(1) NOT NULL DEFAULT '0',
  `included` tinyint(1) NOT NULL DEFAULT '0',
  `price` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cc_profile_id` (`cc_profile_id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `cc_transit_log_ibfk_1` FOREIGN KEY (`cc_profile_id`) REFERENCES `cc_profile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`duration_type`utf8_general_ci	;
CREATE TABLE `duration_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Тип периода'	;
#	TD`duration_type`utf8_general_ci	;
INSERT INTO `duration_type` VALUES 
(1,'Год'),
(2,'Месяц'),
(3,'Неделя'),
(4,'День'),
(5,'Час')	;
#	TC`engine_mark`utf8_general_ci	;
CREATE TABLE `engine_mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`engine_mark`utf8_general_ci	;
INSERT INTO `engine_mark` VALUES 
(1,'Volvo'),
(2,'Penta'),
(3,'Caterpillar'),
(4,'Yanmar')	;
#	TC`engine_type`utf8_general_ci	;
CREATE TABLE `engine_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`engine_type`utf8_general_ci	;
INSERT INTO `engine_type` VALUES 
(1,'Бензин'),
(2,'Дизель'),
(3,'Электро')	;
#	TC`friends_link`utf8_general_ci	;
CREATE TABLE `friends_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) NOT NULL COMMENT 'ID капитана',
  `type_id` int(11) NOT NULL COMMENT 'ID типа связи',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `c_id` (`c_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `friends_link_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `friends_link_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `friends_link_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Дружественные связи вне сайта (приглашения)'	;
#	TC`friends_link_type`utf8_general_ci	;
CREATE TABLE `friends_link_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Типы дружественных связей вне проекта'	;
#	TD`friends_link_type`utf8_general_ci	;
INSERT INTO `friends_link_type` VALUES 
(1,'email'),
(2,'facebook'),
(3,'vkontakte'),
(4,'odnoklassniki')	;
#	TC`gender`utf8_general_ci	;
CREATE TABLE `gender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`gender`utf8_general_ci	;
INSERT INTO `gender` VALUES 
(1,'male'),
(2,'female')	;
#	TC`jib_furling`utf8_general_ci	;
CREATE TABLE `jib_furling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`jib_furling`utf8_general_ci	;
INSERT INTO `jib_furling` VALUES 
(1,'Furling'),
(2,'Classic')	;
#	TC`jib_type`utf8_general_ci	;
CREATE TABLE `jib_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`jib_type`utf8_general_ci	;
INSERT INTO `jib_type` VALUES 
(1,'Jib'),
(2,'Genoa')	;
#	TC`m_profile`utf8_general_ci	;
CREATE TABLE `m_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `m_id` int(11) NOT NULL COMMENT 'ID менеджера ЧК',
  `cc_id` int(11) NOT NULL COMMENT 'ID чартерной компании',
  `phone` varchar(20) DEFAULT NULL,
  `avatar` text,
  PRIMARY KEY (`id`),
  KEY `cc_id` (`cc_id`),
  KEY `m_id` (`m_id`),
  CONSTRAINT `m_profile_ibfk_1` FOREIGN KEY (`cc_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `m_profile_ibfk_2` FOREIGN KEY (`m_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Профиль менеджера ЧК'	;
#	TC`media_type`utf8_general_ci	;
CREATE TABLE `media_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`media_type`utf8_general_ci	;
INSERT INTO `media_type` VALUES 
(1,'NON'),
(2,'CD'),
(3,'MP3'),
(4,'DVD')	;
#	TC`message`utf8_general_ci	;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL COMMENT 'ID отправителя',
  `recipient_id` int(11) NOT NULL COMMENT 'ID получателя',
  `order_id` int(11) NOT NULL COMMENT 'ID заказа',
  `text` text NOT NULL,
  `out_date` date NOT NULL COMMENT 'Дата отправки',
  `in_date` date DEFAULT NULL COMMENT 'Дата прочтения',
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `recipient_id` (`recipient_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `message_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `message_ibfk_2` FOREIGN KEY (`recipient_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `message_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Система обмена сообщениями'	;
#	TC`nationality`utf8_general_ci	;
CREATE TABLE `nationality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`nationality`utf8_general_ci	;
INSERT INTO `nationality` VALUES 
(1,'Russian'),
(2,'English')	;
#	TC`order_options`utf8_general_ci	;
CREATE TABLE `order_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Доступные доп. опции для заказов'	;
#	TC`order_status`utf8_general_ci	;
CREATE TABLE `order_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Статусы заказов'	;
#	TD`order_status`utf8_general_ci	;
INSERT INTO `order_status` VALUES 
(1,'Голубой'),
(2,'Желтый'),
(3,'Красный'),
(4,'Розовый'),
(5,'Зеленый')	;
#	TC`order_status_history`utf8_general_ci	;
CREATE TABLE `order_status_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `order_status_history_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_status_history_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `order_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='История изменения статусов заказа'	;
#	TC`orders`utf8_general_ci	;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yacht_id` int(11) DEFAULT NULL COMMENT 'ID яхты ЧК',
  `yacht_name` int(11) NOT NULL COMMENT 'Название яхты на момент заказа',
  `yacht_latitude` float NOT NULL,
  `yacht_longitude` float NOT NULL,
  `captain_id` int(11) DEFAULT NULL COMMENT 'ID капитана',
  `manager_id` int(11) DEFAULT NULL COMMENT 'ID менеджера ЧК',
  `date_from` date NOT NULL,
  `duration` int(11) NOT NULL,
  `duration_type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `status_end` date DEFAULT NULL,
  `base_price` float NOT NULL,
  `site_price` float NOT NULL,
  `repeater` int(11) NOT NULL DEFAULT '0',
  `_long` int(11) NOT NULL DEFAULT '0',
  `early` int(11) NOT NULL DEFAULT '0',
  `extra` int(11) NOT NULL DEFAULT '0',
  `charter_price` float NOT NULL,
  `site_commission` int(11) NOT NULL,
  `total` float NOT NULL,
  `additional_price` float NOT NULL DEFAULT '0',
  `additional_text` text,
  PRIMARY KEY (`id`),
  KEY `yacht_id` (`yacht_id`),
  KEY `captain_id` (`captain_id`),
  KEY `manager_id` (`manager_id`),
  KEY `status_id` (`status_id`),
  KEY `duration_type_id` (`duration_type_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`yacht_id`) REFERENCES `cc_fleets` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`captain_id`) REFERENCES `tbl_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`manager_id`) REFERENCES `tbl_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `order_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_6` FOREIGN KEY (`duration_type_id`) REFERENCES `duration_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Заказы на яхты'	;
#	TC`price_current_year`utf8_general_ci	;
CREATE TABLE `price_current_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yacht_id` int(11) NOT NULL COMMENT 'ID яхты ЧК',
  `date_from` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_type_id` int(11) NOT NULL,
  `price` float DEFAULT NULL,
  `deposit` float DEFAULT NULL,
  `deposit_insurance_price` float DEFAULT NULL,
  `deposit_insurance_deposit` float DEFAULT NULL,
  `last_minute` int(11) DEFAULT NULL,
  `week_before` int(11) DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `yacht_id` (`yacht_id`),
  KEY `duration_type_id` (`duration_type_id`),
  CONSTRAINT `price_current_year_ibfk_1` FOREIGN KEY (`yacht_id`) REFERENCES `cc_fleets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `price_current_year_ibfk_2` FOREIGN KEY (`duration_type_id`) REFERENCES `duration_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`price_next_year`utf8_general_ci	;
CREATE TABLE `price_next_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yacht_id` int(11) NOT NULL COMMENT 'ID яхты ЧК',
  `date_from` date DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `duration_type_id` int(11) NOT NULL,
  `price` float DEFAULT NULL,
  `deposit` float DEFAULT NULL,
  `deposit_insurance_price` float DEFAULT NULL,
  `deposit_insurance_deposit` float DEFAULT NULL,
  `last_minute` int(11) DEFAULT NULL,
  `week_before` int(11) DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `yacht_id` (`yacht_id`),
  KEY `duration_type_id` (`duration_type_id`),
  CONSTRAINT `price_next_year_ibfk_1` FOREIGN KEY (`yacht_id`) REFERENCES `cc_fleets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `price_next_year_ibfk_2` FOREIGN KEY (`duration_type_id`) REFERENCES `duration_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`questions`utf8_general_ci	;
CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Вопросы анкеты'	;
#	TC`rights_auth_assignment`utf8_general_ci	;
CREATE TABLE `rights_auth_assignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`),
  CONSTRAINT `rights_auth_assignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `rights_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`rights_auth_assignment`utf8_general_ci	;
INSERT INTO `rights_auth_assignment` VALUES 
('admin','1',\N,'N;')	;
#	TC`rights_auth_item`utf8_general_ci	;
CREATE TABLE `rights_auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`rights_auth_item`utf8_general_ci	;
INSERT INTO `rights_auth_item` VALUES 
('admin',2,\N,\N,'N;'),
('Administrator',2,'Администратор',\N,'N;'),
('Authenticated',2,'Авторизованный пользователь',\N,'N;'),
('C',2,'Капитан',\N,'N;'),
('CC',2,'Чартерная компания',\N,'N;'),
('Guest',2,'Не авторизованный пользователь',\N,'N;'),
('Manager',2,'Менеджер чартерной компании',\N,'N;')	;
#	TC`rights_auth_item_child`utf8_general_ci	;
CREATE TABLE `rights_auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `rights_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `rights_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rights_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `rights_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`rights_auth_item_child`utf8_general_ci	;
INSERT INTO `rights_auth_item_child` VALUES 
('C','Authenticated'),
('Manager','Authenticated'),
('Administrator','C'),
('Administrator','CC'),
('Authenticated','Guest'),
('CC','Manager')	;
#	TC`rights_rights`utf8_general_ci	;
CREATE TABLE `rights_rights` (
  `itemname` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`itemname`),
  CONSTRAINT `rights_rights_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `rights_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sail_furling`utf8_general_ci	;
CREATE TABLE `sail_furling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sail_material`utf8_general_ci	;
CREATE TABLE `sail_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sy_profile`utf8_general_ci	;
CREATE TABLE `sy_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT NULL,
  `name` text,
  `shipyard_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `_index_id` int(11) DEFAULT NULL,
  `modification_id` int(11) DEFAULT NULL,
  `built_date` date DEFAULT NULL,
  `renovation_date` date DEFAULT NULL,
  `double_cabins` int(11) DEFAULT NULL,
  `bunk_cabins` int(11) DEFAULT NULL,
  `twin_cabins` int(11) DEFAULT NULL,
  `single_cabins` int(11) DEFAULT NULL,
  `berth_cabin` int(11) DEFAULT NULL,
  `berth_salon` int(11) DEFAULT NULL,
  `crew_cabins` int(11) DEFAULT NULL,
  `crew_berth` int(11) DEFAULT NULL,
  `WC` int(11) DEFAULT NULL,
  `shower` int(11) DEFAULT NULL,
  `main_sail_area` float DEFAULT NULL,
  `main_sail_full_battened` tinyint(1) NOT NULL DEFAULT '0',
  `main_sail_furling_id` int(11) DEFAULT NULL,
  `main_sail_material_id` int(11) DEFAULT NULL,
  `jib_type_id` int(11) DEFAULT NULL,
  `jib_area` float DEFAULT NULL,
  `jib_automatic` tinyint(1) NOT NULL DEFAULT '0',
  `jib_furling_id` int(11) DEFAULT NULL,
  `jib_material_id` int(11) DEFAULT NULL,
  `winches` int(11) DEFAULT NULL,
  `el_winches` int(11) DEFAULT NULL,
  `spinnaker` tinyint(1) NOT NULL DEFAULT '0',
  `spinnaker_area` float DEFAULT NULL,
  `spinnaker_price` float DEFAULT NULL,
  `spinnaker_deposiit` float DEFAULT NULL,
  `gennaker` tinyint(1) NOT NULL DEFAULT '0',
  `gennaker_area` float DEFAULT NULL,
  `gennaker_price` float DEFAULT NULL,
  `gennaker_deposit` float DEFAULT NULL,
  `length_m` float DEFAULT NULL,
  `beam` float DEFAULT NULL,
  `draft` float DEFAULT NULL,
  `mast_draught` float DEFAULT NULL,
  `displacement` int(11) DEFAULT NULL,
  `no_of_engine` int(11) DEFAULT NULL,
  `engine_type_id` int(11) DEFAULT NULL,
  `engine_mark_id` int(11) DEFAULT NULL,
  `engine_power_hp` float DEFAULT NULL,
  `engine_power_kW` float DEFAULT NULL,
  `wheel_type_id` int(11) DEFAULT NULL,
  `wheel_no` int(11) DEFAULT NULL,
  `rudder` int(11) DEFAULT NULL,
  `folding_propeller` tinyint(1) NOT NULL DEFAULT '0',
  `bow_thruster` tinyint(1) NOT NULL DEFAULT '0',
  `auto_pilot` tinyint(1) NOT NULL DEFAULT '0',
  `GPS` tinyint(1) NOT NULL DEFAULT '0',
  `in_cockpit` tinyint(1) NOT NULL DEFAULT '0',
  `wind` tinyint(1) NOT NULL DEFAULT '0',
  `speed` tinyint(1) NOT NULL DEFAULT '0',
  `depht` tinyint(1) NOT NULL DEFAULT '0',
  `compass` tinyint(1) NOT NULL DEFAULT '0',
  `VHF` tinyint(1) NOT NULL DEFAULT '0',
  `radio` tinyint(1) NOT NULL DEFAULT '0',
  `inverter` tinyint(1) NOT NULL DEFAULT '0',
  `radar` tinyint(1) NOT NULL DEFAULT '0',
  `local_charts` tinyint(1) NOT NULL DEFAULT '0',
  `local_pilot` tinyint(1) NOT NULL DEFAULT '0',
  `tick_cockpit` tinyint(1) NOT NULL DEFAULT '0',
  `tick_deck` tinyint(1) NOT NULL DEFAULT '0',
  `sprayhood` tinyint(1) NOT NULL DEFAULT '0',
  `bimini` tinyint(1) NOT NULL DEFAULT '0',
  `hard_top` tinyint(1) DEFAULT '0',
  `flybridge` tinyint(1) NOT NULL DEFAULT '0',
  `cockpit_table` tinyint(1) NOT NULL DEFAULT '0',
  `moveable` tinyint(1) NOT NULL DEFAULT '0',
  `cockpit_speakers` tinyint(1) NOT NULL DEFAULT '0',
  `hot_water` tinyint(1) NOT NULL DEFAULT '0',
  `heater` tinyint(1) NOT NULL DEFAULT '0',
  `aircon` tinyint(1) NOT NULL DEFAULT '0',
  `water_maker` tinyint(1) NOT NULL DEFAULT '0',
  `generator` tinyint(1) NOT NULL DEFAULT '0',
  `media_type_id` int(11) DEFAULT NULL,
  `aux` tinyint(1) NOT NULL DEFAULT '0',
  `usb` tinyint(1) NOT NULL DEFAULT '0',
  `TV` tinyint(1) NOT NULL DEFAULT '0',
  `water_tank` int(11) DEFAULT NULL,
  `fuel_tank` int(11) DEFAULT NULL,
  `grey_tank` tinyint(1) NOT NULL DEFAULT '0',
  `fridge` tinyint(1) NOT NULL DEFAULT '0',
  `fridge_no` int(11) DEFAULT NULL,
  `freeser` tinyint(1) NOT NULL DEFAULT '0',
  `gas_cooker` tinyint(1) NOT NULL DEFAULT '0',
  `microwave` tinyint(1) NOT NULL DEFAULT '0',
  `kit_equip` tinyint(1) NOT NULL DEFAULT '0',
  `local_skipper` tinyint(1) NOT NULL DEFAULT '0',
  `other_details` text,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `site_discount` float DEFAULT NULL,
  `last_cleaning_incl` tinyint(1) NOT NULL DEFAULT '0',
  `last_cleaning_price` float DEFAULT NULL,
  `last_cleaning_obl` tinyint(1) NOT NULL DEFAULT '0',
  `race_sail` tinyint(1) NOT NULL DEFAULT '0',
  `race_sail_material_id` int(11) DEFAULT NULL,
  `race_sail_price_incl` int(11) DEFAULT NULL,
  `race_sail_price` float DEFAULT NULL,
  `race_sail_price_obl` tinyint(1) NOT NULL DEFAULT '0',
  `race_sail_deposit` float DEFAULT NULL,
  `race_sail_deposit_obl` tinyint(1) NOT NULL DEFAULT '0',
  `IRC_scan` text,
  `ORC_scan` text,
  `race_preparation` float DEFAULT NULL,
  `hull_cleaning` float DEFAULT NULL,
  `crew_license` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `main_sail_furling_id` (`main_sail_furling_id`),
  KEY `main_sail_material_id` (`main_sail_material_id`),
  KEY `jib_type_id` (`jib_type_id`),
  KEY `jib_furling_id` (`jib_furling_id`),
  KEY `jib_material_id` (`jib_material_id`),
  KEY `engine_type_id` (`engine_type_id`),
  KEY `engine_mark_id` (`engine_mark_id`),
  KEY `wheel_type_id` (`wheel_type_id`),
  KEY `media_type_id` (`media_type_id`),
  KEY `race_sail_material_id` (`race_sail_material_id`),
  KEY `shipyard_id` (`shipyard_id`),
  KEY `model_id` (`model_id`),
  KEY `_index_id` (`_index_id`),
  KEY `modification_id` (`modification_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `sy_profile_ibfk_1` FOREIGN KEY (`main_sail_furling_id`) REFERENCES `sail_furling` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_10` FOREIGN KEY (`race_sail_material_id`) REFERENCES `sail_material` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_12` FOREIGN KEY (`shipyard_id`) REFERENCES `yacht_shipyard` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_13` FOREIGN KEY (`model_id`) REFERENCES `yacht_model` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_14` FOREIGN KEY (`_index_id`) REFERENCES `yacht_index` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_15` FOREIGN KEY (`modification_id`) REFERENCES `yacht_modification` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_16` FOREIGN KEY (`type_id`) REFERENCES `yacht_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_2` FOREIGN KEY (`main_sail_material_id`) REFERENCES `sail_material` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_3` FOREIGN KEY (`jib_type_id`) REFERENCES `jib_type` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_4` FOREIGN KEY (`jib_furling_id`) REFERENCES `jib_furling` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_5` FOREIGN KEY (`jib_material_id`) REFERENCES `sail_material` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_6` FOREIGN KEY (`engine_type_id`) REFERENCES `engine_type` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_7` FOREIGN KEY (`engine_mark_id`) REFERENCES `engine_mark` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_8` FOREIGN KEY (`wheel_type_id`) REFERENCES `wheel_type` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sy_profile_ibfk_9` FOREIGN KEY (`media_type_id`) REFERENCES `media_type` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Профиль парусной яхты'	;
#	TC`tbl_profiles`utf8_general_ci	;
CREATE TABLE `tbl_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles`utf8_general_ci	;
INSERT INTO `tbl_profiles` VALUES 
(1,'Admin','Administrator'),
(2,'Demo','Demo')	;
#	TC`tbl_profiles_fields`utf8_general_ci	;
CREATE TABLE `tbl_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` varchar(15) NOT NULL DEFAULT '0',
  `field_size_min` varchar(15) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles_fields`utf8_general_ci	;
INSERT INTO `tbl_profiles_fields` VALUES 
(1,'lastname','Last Name','VARCHAR','50','3',1,'','','Incorrect Last Name (length between 3 and 50 characters).','','','','',1,3),
(2,'firstname','First Name','VARCHAR','50','3',1,'','','Incorrect First Name (length between 3 and 50 characters).','','','','',0,3)	;
#	TC`tbl_users`utf8_general_ci	;
CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`tbl_users`utf8_general_ci	;
INSERT INTO `tbl_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','webmaster@example.com','9a24eff8c15a6a141ece27eb6947da0f','2013-11-16 03:00:50','2013-12-09 12:51:57',1,1),
(2,'demo','fe01ce2a7fbac8fafaed7c982a04e229','demo@example.com','099f825543f7850cc038b90aaff39fac','2013-11-16 03:00:50','2013-11-26 13:46:49',0,1)	;
#	TC`wheel_type`utf8_general_ci	;
CREATE TABLE `wheel_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`yacht_favorites`utf8_general_ci	;
CREATE TABLE `yacht_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) NOT NULL COMMENT 'ID капитана',
  `yacht_id` int(11) NOT NULL COMMENT 'ID яхты ЧК',
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `c_id` (`c_id`),
  KEY `yacht_id` (`yacht_id`),
  CONSTRAINT `yacht_favorites_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `yacht_favorites_ibfk_2` FOREIGN KEY (`yacht_id`) REFERENCES `cc_fleets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`yacht_history_watch`utf8_general_ci	;
CREATE TABLE `yacht_history_watch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) NOT NULL COMMENT 'ID капитана',
  `yacht_id` int(11) NOT NULL COMMENT 'ID яхты ЧК',
  `count` int(11) NOT NULL COMMENT 'Счетчик числа просмотров',
  `last_date` date NOT NULL COMMENT 'Дата последнего просмотра',
  `date` date NOT NULL COMMENT 'Дата первого просмотра',
  PRIMARY KEY (`id`),
  KEY `c_id` (`c_id`),
  KEY `yacht_id` (`yacht_id`),
  KEY `c_id_2` (`c_id`),
  KEY `yacht_id_2` (`yacht_id`),
  CONSTRAINT `yacht_history_watch_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `yacht_history_watch_ibfk_2` FOREIGN KEY (`yacht_id`) REFERENCES `cc_fleets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`yacht_index`utf8_general_ci	;
CREATE TABLE `yacht_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`),
  CONSTRAINT `yacht_index_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `yacht_model` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8	;
#	TD`yacht_index`utf8_general_ci	;
INSERT INTO `yacht_index` VALUES 
(1,1,'31'),
(2,1,'33'),
(3,1,'37'),
(4,1,'39'),
(5,1,'40'),
(6,1,'42'),
(7,1,'45'),
(8,1,'46'),
(9,1,'50'),
(10,1,'51'),
(11,1,'55'),
(12,1,'56'),
(13,2,'42'),
(14,2,'46'),
(15,3,'39.3'),
(16,3,'43.3'),
(17,3,'43.4'),
(18,4,'20'),
(19,4,'25'),
(20,4,'27.7'),
(21,4,'30'),
(22,4,'35'),
(23,4,'40'),
(24,4,'45'),
(25,4,'47.7'),
(26,4,'50'),
(27,5,'31'),
(28,5,'34'),
(29,5,'37'),
(30,5,'38'),
(31,5,'40'),
(32,5,'41'),
(33,5,'43'),
(34,5,'45'),
(35,5,'46'),
(36,5,'48'),
(37,5,'50'),
(38,5,'54'),
(39,5,'55'),
(40,5,'58'),
(41,5,'311'),
(42,5,'323'),
(43,5,'361'),
(44,5,'393'),
(45,5,'411'),
(46,5,'423'),
(47,5,'440'),
(48,5,'473'),
(49,5,'523'),
(50,36,'44'),
(51,36,'46'),
(52,36,'47'),
(53,36,'49'),
(54,36,'55'),
(55,37,'50'),
(56,37,'57'),
(57,38,'40'),
(58,38,'50'),
(59,38,'310'),
(60,38,'335'),
(61,38,'365'),
(62,38,'375'),
(63,38,'380'),
(64,38,'385'),
(65,38,'410'),
(66,38,'445'),
(67,38,'450'),
(68,38,'455'),
(69,38,'485'),
(70,38,'500'),
(71,38,'525'),
(72,39,'45'),
(73,39,'210'),
(74,39,'310'),
(75,39,'350'),
(76,39,'400'),
(77,39,'410'),
(78,39,'450'),
(79,40,'37'),
(80,40,'39'),
(81,40,'40'),
(82,40,'43'),
(83,40,'46.3'),
(84,40,'47'),
(85,40,'50'),
(86,40,'54'),
(87,40,'56'),
(88,41,'53'),
(89,41,'57'),
(90,3,'50.4'),
(91,3,'50.5'),
(92,6,'43'),
(93,6,'46'),
(94,6,'50'),
(95,6,'55'),
(96,7,'21'),
(97,7,'26'),
(98,7,'31'),
(99,8,'35'),
(100,8,'38'),
(101,8,'41'),
(102,8,'45'),
(103,8,'50'),
(104,9,'52'),
(105,9,'62'),
(106,9,'73'),
(107,9,'85'),
(108,9,'100'),
(109,10,'33'),
(110,10,'43'),
(111,10,'51'),
(112,11,'36'),
(113,11,'40'),
(114,11,'45'),
(115,12,'344'),
(116,12,'384'),
(117,12,'394'),
(118,12,'444'),
(119,12,'494'),
(120,12,'514'),
(121,13,'3200'),
(122,14,'30'),
(123,14,'33'),
(124,14,'35'),
(125,14,'36'),
(126,14,'39'),
(127,14,'40'),
(128,14,'41'),
(129,14,'42'),
(130,14,'43'),
(131,14,'44'),
(132,14,'45'),
(133,14,'45.1'),
(134,14,'45.2'),
(135,14,'49'),
(136,14,'50'),
(137,14,'52.2'),
(138,14,'54'),
(139,14,'379'),
(140,14,'409'),
(141,14,'439'),
(142,14,'469'),
(143,14,'509'),
(144,42,'301'),
(145,42,'311'),
(146,42,'312'),
(147,42,'315'),
(148,42,'320'),
(149,42,'325'),
(150,42,'341'),
(151,42,'342'),
(152,42,'345'),
(153,42,'350'),
(154,42,'355'),
(155,42,'370'),
(156,42,'371'),
(157,42,'375'),
(158,42,'385'),
(159,42,'400'),
(160,42,'411'),
(161,42,'415'),
(162,42,'430'),
(163,42,'445'),
(164,42,'461'),
(165,42,'470'),
(166,42,'495'),
(167,42,'505'),
(168,42,'531'),
(169,42,'540'),
(170,42,'545'),
(171,42,'575'),
(172,42,'630'),
(173,43,'15'),
(174,43,'18'),
(175,43,'22'),
(176,43,'27'),
(177,43,'33'),
(178,43,'36'),
(179,43,'40'),
(180,43,'41'),
(181,43,'45'),
(182,43,'50'),
(183,43,'55'),
(184,43,'306'),
(185,15,'34'),
(186,15,'38'),
(187,15,'42'),
(188,15,'47'),
(189,15,'52'),
(190,44,'33'),
(191,44,'35'),
(192,44,'38'),
(193,44,'41'),
(194,44,'44'),
(195,44,'45'),
(196,44,'60'),
(197,16,'72'),
(198,17,'62'),
(199,17,'72'),
(200,18,'37'),
(201,18,'42'),
(202,18,'44'),
(203,18,'48'),
(204,18,'58'),
(205,18,'60'),
(206,45,'32'),
(207,45,'37'),
(208,45,'38'),
(209,45,'39'),
(210,45,'40'),
(211,45,'41'),
(212,45,'43'),
(213,45,'47'),
(214,46,'34'),
(215,46,'46'),
(216,46,'47'),
(217,46,'50'),
(218,46,'51'),
(219,46,'54'),
(220,46,'55'),
(221,46,'62'),
(222,46,'78'),
(223,46,'80'),
(224,19,'34'),
(225,19,'35'),
(226,19,'41'),
(227,19,'412'),
(228,19,'65'),
(229,20,'38'),
(230,20,'42'),
(231,20,'45'),
(232,20,'50'),
(233,21,'33'),
(234,21,'38'),
(235,21,'44'),
(236,21,'50'),
(237,21,'55'),
(238,22,'38'),
(239,23,'43'),
(240,24,'44'),
(241,25,'40'),
(242,26,'41'),
(243,27,'36'),
(244,28,'44'),
(245,29,'48'),
(246,30,'57'),
(247,31,'80'),
(248,32,'67'),
(249,33,'37'),
(250,33,'43'),
(251,47,'32'),
(252,47,'38'),
(253,47,'39'),
(254,47,'40'),
(255,47,'41'),
(256,47,'47'),
(257,48,'380'),
(258,48,'400'),
(259,48,'440'),
(260,48,'450'),
(261,48,'500'),
(262,48,'560')	;
#	TC`yacht_model`utf8_general_ci	;
CREATE TABLE `yacht_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shipyard_id` int(11) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shipyard_id` (`shipyard_id`),
  CONSTRAINT `yacht_model_ibfk_1` FOREIGN KEY (`shipyard_id`) REFERENCES `yacht_shipyard` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8	;
#	TD`yacht_model`utf8_general_ci	;
INSERT INTO `yacht_model` VALUES 
(1,1,'Cruiser'),
(2,1,'Vision'),
(3,2,'Cyclades'),
(4,2,'First'),
(5,2,'Oceanis'),
(6,2,'Sense'),
(7,3,'Comet Smart'),
(8,3,'Comet Sport'),
(9,3,'Comet Raised Saloon'),
(10,4,'Gib Sea'),
(11,4,'Performance'),
(12,5,'Impression'),
(13,7,'Sun Fast'),
(14,7,'Sun Odyssey'),
(15,10,'Harmony'),
(16,12,'Classic'),
(17,12,'Custom'),
(18,12,'One'),
(19,15,'X'),
(20,15,'Xc'),
(21,15,'Xp'),
(22,16,'Athena'),
(23,16,'Belize'),
(24,16,'Hélia'),
(25,16,'Lavezzi'),
(26,16,'Lipari'),
(27,16,'Mahe'),
(28,16,'Orana'),
(29,16,'Salina'),
(30,16,'Sanya'),
(31,16,'Taiti'),
(32,16,'Victoria'),
(33,17,'GTS'),
(36,1,'Bavaria'),
(37,2,'Beneteau'),
(38,4,'Dufour'),
(39,5,'Elan'),
(40,6,'Grand Soleil'),
(41,7,'Jeanneau'),
(42,8,'Hanse'),
(43,9,'Hunter'),
(44,11,'Salona'),
(45,13,'Sydney'),
(46,14,'Vismara'),
(47,17,'Sydney'),
(48,18,'Lagoon')	;
#	TC`yacht_modification`utf8_general_ci	;
CREATE TABLE `yacht_modification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`),
  CONSTRAINT `yacht_modification_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `yacht_model` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8	;
#	TD`yacht_modification`utf8_general_ci	;
INSERT INTO `yacht_modification` VALUES 
(1,1,'(Lim. Ed.)'),
(2,1,'S'),
(3,4,'S'),
(4,4,'CR'),
(5,5,'Family'),
(6,5,'Clipper'),
(7,7,'S'),
(8,8,'S'),
(9,8,'C'),
(10,9,'RS'),
(11,38,'Classic'),
(12,38,'GL'),
(13,38,'E'),
(14,40,'R'),
(15,14,'I'),
(16,14,'DS'),
(17,42,'e'),
(18,42,'Epoxy'),
(19,17,'RS'),
(20,17,'DH'),
(21,45,'OD'),
(22,45,'GTS'),
(23,45,'CR'),
(24,46,'DS'),
(25,46,'Fast Cruiser'),
(26,46,'RC'),
(27,46,'Hybrid'),
(28,46,'K9'),
(29,46,'b2'),
(30,46,'Sport'),
(31,46,'Maxi'),
(32,23,'M'),
(33,23,'Quatuor'),
(34,24,'Quatuor'),
(35,26,'Evolution'),
(36,27,'Evolution'),
(37,29,'Evolution'),
(38,28,'Quatuor'),
(39,28,'Maestro'),
(40,47,'OD'),
(41,47,'CR'),
(42,48,'S2')	;
#	TC`yacht_photo`utf8_general_ci	;
CREATE TABLE `yacht_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yacht_id` int(11) NOT NULL,
  `link` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `yacht_id` (`yacht_id`),
  CONSTRAINT `yacht_photo_ibfk_1` FOREIGN KEY (`yacht_id`) REFERENCES `cc_fleets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`yacht_shipyard`utf8_general_ci	;
CREATE TABLE `yacht_shipyard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yacht_type_id` int(11) NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `yacht_type_id` (`yacht_type_id`),
  CONSTRAINT `yacht_shipyard_ibfk_1` FOREIGN KEY (`yacht_type_id`) REFERENCES `yacht_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8	;
#	TD`yacht_shipyard`utf8_general_ci	;
INSERT INTO `yacht_shipyard` VALUES 
(1,1,'Bavaria'),
(2,1,'Beneteau'),
(3,1,'Comar'),
(4,1,'Dufour'),
(5,1,'Elan'),
(6,1,'Grand Soleil'),
(7,1,'Jeanneau'),
(8,1,'Hanse'),
(9,1,'Hunter'),
(10,1,'Poncin Yachts'),
(11,1,'Salona'),
(12,1,'Solaris'),
(13,1,'Sydney'),
(14,1,'Vismara'),
(15,1,'X-Yachts'),
(16,2,'Fontaine Pajot'),
(17,2,'Sydney'),
(18,2,'Lagoon')	;
#	TC`yacht_type`utf8_general_ci	;
CREATE TABLE `yacht_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Таблица связей типов яхт с профилями'	;
#	TD`yacht_type`utf8_general_ci	;
INSERT INTO `yacht_type` VALUES 
(1,'sail_yacht'),
(2,'sail_catamaran')	;
